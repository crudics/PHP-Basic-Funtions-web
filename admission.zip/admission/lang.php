<?php

echo 'Kamran' . ' Qadir';
	   
$i  = 1;
echo $i;

?>