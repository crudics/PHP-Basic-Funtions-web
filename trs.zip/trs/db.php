<?php  
	$conn = mysqli_connect('localhost', 'root', '', 'trs');
	 if (!$conn)
    {
	 die('Could not connect: ' . mysql_error());
	}
?>

 